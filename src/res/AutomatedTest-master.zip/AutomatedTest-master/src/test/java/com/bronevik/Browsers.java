package com.bronevik;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public enum Browsers {
    chrome("chrome"),
    firefox("firefox"),
    edge("edge"),
    ie("ie");

    private String browserName;

    Browsers(String browserName) {
        this.browserName = browserName;
    }

    public WebDriver getBrowser() {
        if(this.browserName.equals(chrome.browserName)) {
            System.setProperty("webdriver.chrome.driver", "BrowserDrivers/chromedriver.exe");
            return new ChromeDriver();
        }
        else if(this.browserName.equals(firefox.browserName)) {
            System.setProperty("webdriver.gecko.driver", "BrowserDrivers/geckodriver.exe");
            return new FirefoxDriver();
        }
        else if(this.browserName.equals(edge.getBrowserName())) {
            System.setProperty("webdriver.edge.driver", "BrowserDrivers/MicrosoftWebDriver.exe");
            return new EdgeDriver();
        }
        else if(this.browserName.equals(ie.getBrowserName())) {
            System.setProperty("webdriver.ie.driver", "BrowserDrivers/IEDriverServer.exe");
            return new InternetExplorerDriver();
        }
        return new ChromeDriver();
    }

    public String getBrowserName() {
        return browserName;
    }
}
