package com.bronevik;

import io.qameta.allure.Epic;
import io.qameta.allure.junit4.DisplayName;
import org.junit.Before;
import org.junit.Test;

public class Tests extends WebDriverSettings {

    private SignUpPage signUpPage;

    @Before
    public void initialSignUpPage() {
        signUpPage = new SignUpPage(webDriver, webDriverWait);
        signUpPage.open();
        signUpPage.waitStart();
    }

    @Test
    @Epic(value = "Бизнес")
    @DisplayName("Тест с верными данными")
    public void successfulRegistrationBusiness() {

        signUpPage.setVisaPurpose("бизнес");
        signUpPage.setVisaType("двукратная");
        signUpPage.setGuestsCount(1);
        signUpPage.setVisaTime(3);
        signUpPage.setResidenceTime(90);
        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setGuestPosition(0,"Director");
        signUpPage.setDateArrival(" 05012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setObtaining("Vienna, Austria");
        signUpPage.setWorkPlace("Sima-land");
        signUpPage.setWorkAddress("st. Chernyakhovskogo, 86/12, Yekaterinburg, Sverdlovsk Region, 620010");
        signUpPage.setWorkPhone("+78002341000");
        signUpPage.setRandomEmail();
        signUpPage.setClientPhone("+79991912499");
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с верными данными")
    public void successfulRegistrationTourist() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с пустыми данными")
    public void checkNullValues() {

        signUpPage.setGuestName(0,"");
        signUpPage.setGuestSurname(0,"");
        signUpPage.setGuestDateBirth(0,"");
        signUpPage.setGuestPassport(0,"");
        signUpPage.setGuestPassportExpiry(0,"");
        signUpPage.setDateArrival("");
        signUpPage.setDateDeparture("");
        signUpPage.setRouteCity(0, "");
        signUpPage.setRouteHotel(0, "");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверной именем - 12345")
    public void checkIncorrectName() {

        signUpPage.setGuestName(0,"12345");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверной фамилией - 12345")
    public void checkIncorrectSurname() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"12345");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверной датой рождения - 99.99.9999")
    public void checkIncorrectDateBirth() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"99999999");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с просроченной датой паспорта")
    public void checkOverduePassportExpiry() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062018");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с датой заезда, которая превышает лимит визы")
    public void checkOverdueDateArrival() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012018");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с датой выезда, раньше даты заезда")
    public void checkOverdueDateDeparture() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("04012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверным названием города - 99999")
    public void checkIncorrectRouteCity() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "99999");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверным названием гостиницы - 99999")
    public void checkIncorrectRouteHotel() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "99999");
        signUpPage.setRandomEmail();
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с пустой почтой")
    public void checkNullEmail() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setEmail("");
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверной почтой - test@")
    public void checkIncorrectEmail2() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setEmail("test@");
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }

    @Test
    @Epic(value = "Туризм")
    @DisplayName("Тест с неверной почтой - test@m")
    public void checkIncorrectEmail() {

        signUpPage.setGuestName(0,"Name");
        signUpPage.setGuestSurname(0,"Surname");
        signUpPage.setGuestGender(0, 'ж');
        signUpPage.setGuestDateBirth(0,"24081998");
        signUpPage.setGuestCountry(0, "22");
        signUpPage.setGuestPassport(0,"5216 535430");
        signUpPage.setGuestPassportExpiry(0,"12062021");
        signUpPage.setDateArrival("05012020");
        signUpPage.setDateDeparture("10012020");
        signUpPage.setRouteCity(0, "Ekaterinburg");
        signUpPage.setRouteHotel(0, "Onegin");
        signUpPage.setEmail("test@m");
        signUpPage.setAcceptTerms();
        signUpPage.setTermsPersonData();
        signUpPage.sendVisa();

        signUpPage.waitErrorEnd();
    }
}
