package com.bronevik;

import io.qameta.allure.Step;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import java.util.Random;

public class SignUpPage {

    private WebDriver webDriver;
    private WebDriverWait webDriverWait;

    public SignUpPage(WebDriver webDriver, WebDriverWait webDriverWait) {
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
    }

    /**
     * Найти элемент по xpath
     * @param xpath
     */
    private WebElement findElByXpath(String xpath) {
        return webDriver.findElement(By.xpath(xpath));
    }

    /**
     * Найти элемент по id
     * @param id
     */
    private WebElement findElById(String id) {
        return webDriver.findElement(By.id(id));
    }

    /**
     * Найти элемент по name
     * @param name
     */
    private WebElement findElByName(String name) {
        return webDriver.findElement(By.name(name));
    }

    /**
     * Открытие страницы
     */
    @Step("Открываем страницу заказа визового приглашения")
    public void open() {
        webDriver.get("https://preview-broken-in-u5auzt.bronevik.com/ru/info/russian-visa-invitation/");
    }

    /**
     * Ждем успешной загрузки страницы
     * @return либо открыл, либо упал
     */
    @Step("Ждем успешной загрузки страницы")
    public void waitStart() {
        //Ждем успешной загрузки
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Закажите визовое приглашение в Россию')]")));
    }

    /**
     * Ждем успешной регистрации
     * @return true, если успешно, false - нет
     */
    public boolean isSuccessfulEnding() {
        boolean successfulEnding = false;

        try {
            if(webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[contains(text(),'Проверьте введенные данные')]"))).isDisplayed())
                successfulEnding = true;
        }
        catch (Exception ex)
        {
            successfulEnding = false;
            System.out.println(ex.getMessage());
        }

        return successfulEnding;
    }

    /**
     * Ждем успешной регистрации
     * @return true - успешно, false - нет
     */
    @Step("Ждем успешной регистрации визового приглашения")
    public void waitEnd() {
        //Ждем успешной регистрации
        Assert.assertEquals("Ожидаемая регистрация не удалась!", true, isSuccessfulEnding());
    }

    /**
     * Ждем НЕ успешной регистрации
     * @return true - не успешно, false - успешно?
     */
    @Step("Ждем отказа регистрации визового приглашения")
    public void waitErrorEnd() {
        //Ждем успешной регистрации
        Assert.assertEquals("Ожидаемого отказа регистрации не произошло!", false, isSuccessfulEnding());
    }

    /**
     * Установка типа визы
     * @param purpose - тип (туризм или бизнес)
     */
    @Step("Устанавливаем тип визы - {purpose}")
    public void setVisaPurpose(String purpose) {
        findElByXpath("//input[@type='radio' and @value='" + purpose + "']/..").click();
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка кратности визы
     * @param visaType - кратность визы (однократная, двукратная или многократная)
     */
    @Step("Устанавливаем кратность визы - {visaType}")
    public void setVisaType(String visaType) {
        new Select(findElByName("visaType")).selectByValue(visaType);
    }

    /**
     * Установка колличества гостей
     * @param count - кол-во гостей (1,2 или 3)
     */
    @Step("Устанавливаем количество гостей - {count}")
    public void setGuestsCount(Integer count) {
        findElByXpath("//input[@type='radio' and @value='" + count + "' and @name='guestsCount']/..").click();
    }

    /**
     * Установка времени готовности визы
     * @param time - время готовности визы
     *             Для туризма - 1 = 24 ч, 0 = 15 мин.
     *             Для бизнеса - 4 = 14-22 дн., 3 = 11-13 дн., 2 = 7-10 дн.
     */
    @Step("Устанавливаем готовность визы - {time}")
    public void setVisaTime(Integer time) {
        findElByXpath("//input[@type='radio' and @value='" + time + "' and @name='visaTime']/..").click();
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка времени пребывания
     * @param time - кол-во дней (30 или 90)
     */
    @Step("Устанавливаем время пребывания - {time} дней")
    public void setResidenceTime(Integer time) {
        findElByXpath("//input[@type='radio' and @value='" + time + "' and @name='residenceTime']/..").click();
    }

    /**
     * Установка имени для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param guestName - имя гостя
     */
    @Step("Устанавливаем имя {guestCount}-го гостя - {guestName}")
    public void setGuestName(Integer guestCount, String guestName) {
        findElByName("guests[" + guestCount + "][name]").sendKeys(guestName);
    }

    /**
     * Установка фамилии для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param guestSurname - фамилия гостя
     */
    @Step("Устанавливаем фамилию {guestCount}-го гостя - {guestSurname}")
    public void setGuestSurname(Integer guestCount, String guestSurname) {
        findElByName("guests[" + guestCount + "][surname]").sendKeys(guestSurname);
    }

    /**
     * Установка пола для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param guestGender - пол гостя (ж или м)
     */
    @Step("Устанавливаем пол {guestCount}-го гостя - {guestGender}")
    public void setGuestGender(Integer guestCount, Character guestGender) {
        findElByXpath("//input[@type='radio' and @value='" + guestGender + "' and @name='guests[" + guestCount + "][gender]']/..").click();
    }

    /**
     * Установка даты рождения для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param dateBirth - дата рождения гостя (без пробелов и разделителей - 24081998)
     */
    @Step("Устанавливаем день рождения {guestCount}-го гостя - {dateBirth}")
    public void setGuestDateBirth(Integer guestCount, String dateBirth) {
        if(webDriver instanceof ChromeDriver || webDriver instanceof InternetExplorerDriver || webDriver instanceof EdgeDriver)
            findElByName("guests[" + guestCount + "][dateBirth]").click();
        findElByName("guests[" + guestCount + "][dateBirth]").sendKeys(" " + dateBirth);
    }

    /**
     * Установка страны для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param idCountry - id страны (пример: 22 = Австралия)
     */
    @Step("Устанавливаем id страны {guestCount}-го гостя - {idCountry}")
    public void setGuestCountry(Integer guestCount, String idCountry) {
        new Select(findElByName("guests[" + guestCount + "][country]")).selectByValue(idCountry);
    }

    /**
     * Установка серии и номера паспорта для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param guestPassport - серия и номер паспорта гостя(через пробел)
     */
    @Step("Устанавливаем данные паспорта {guestCount}-го гостя - {guestPassport}")
    public void setGuestPassport(Integer guestCount, String guestPassport) {
        findElByName("guests[" + guestCount + "][passport]").sendKeys(guestPassport);
    }

    /**
     * Установка даты окончания паспорта для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param passportExpiry - дата окончания паспорта гостя(через пробел)
     */
    @Step("Устанавливаем дату окончания паспорта {guestCount}-го гостя - {passportExpiry}")
    public void setGuestPassportExpiry(Integer guestCount, String passportExpiry) {
        if(webDriver instanceof ChromeDriver || webDriver instanceof InternetExplorerDriver || webDriver instanceof EdgeDriver)
            findElByName("guests[" + guestCount + "][passportExpiry]").click();
        findElByName("guests[" + guestCount + "][passportExpiry]").sendKeys(" " + passportExpiry);
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка должности для n-го гостя
     * @param guestCount - n гостя (какой по счету, начиная с 0)
     * @param guestPosition - должность гостя
     */
    @Step("Устанавливаем должность {guestCount}-го гостя - {guestPosition}")
    public void setGuestPosition(Integer guestCount, String guestPosition) {
        findElByName("guests[" + guestCount + "][position]").sendKeys(guestPosition);
    }

    /**
     * Установка даты заезда в РФ
     * @param date - дата заезда (без пробелов и разделителей - 12052019)
     */
    @Step("Устанавливаем дату заезда в РФ - {date}")
    public void setDateArrival(String date) {
        if(webDriver instanceof ChromeDriver || webDriver instanceof InternetExplorerDriver || webDriver instanceof EdgeDriver)
            findElByName("dateArrival").click();
        findElByName("dateArrival").sendKeys(" " + date);
    }

    /**
     * ! ТОЛЬКО ДЛЯ ТУРИЗМА
     * Установка даты выезда из РФ
     * @param date - дата выезда (без пробелов и разделителей - 12052019)
     */
    @Step("Устанавливаем дату выезда из РФ - {date}")
    public void setDateDeparture(String date) {
        if(webDriver instanceof ChromeDriver || webDriver instanceof InternetExplorerDriver || webDriver instanceof EdgeDriver)
            findElByName("dateDeparture").click();
        findElByName("dateDeparture").sendKeys(" " + date);
    }

    /**
     * Установка города назначения для n-го маршрута
     * @param routeCount - номер маршрута (какой по счету, начиная с 0)
     * @param routeCity - город назначения маршрута
     */
    @Step("Устанавливаем город назначения для {routeCount}-го маршрута - {routeCity}")
    public void setRouteCity(Integer routeCount, String routeCity) {
        findElByName("route[" + routeCount + "][city]").sendKeys(routeCity);
    }

    /**
     * Установка гостиницы назначения для n-го маршрута
     * @param routeCount - номер маршрута (какой по счету, начиная с 0)
     * @param routeHotel - гостиница назначения маршрута
     */
    @Step("Устанавливаем гостиницу назначения для {routeCount}-го маршрута - {routeHotel}")
    public void setRouteHotel(Integer routeCount, String routeHotel) {
        findElByName("route[" + routeCount + "][hotel]").sendKeys(routeHotel);
    }

    /**
     * Добавление еще одного маршрута
     */
    @Step("Добавляем еще один маршрут")
    public void addRoute() {
        findElByXpath("//a[@onclick='addHotelField()' and @href='javascript:void(0)']").click();
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка места получения визы
     * @param obtaining - место получение
     */
    @Step("Устанавливаем место получения визы - {obtaining}")
    public void setObtaining(String obtaining) {
        findElByName("obtaining").sendKeys(obtaining);
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка названия рабочей организации
     * @param workPlace - название организации
     */
    @Step("Устанавливаем название организации - {workPlace}")
    public void setWorkPlace(String workPlace) {
        findElByName("workPlace").sendKeys(workPlace);
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка адреса рабочей организации
     * @param workAddress - адрес организации
     */
    @Step("Устанавливаем адрес организации - {workAddress}")
    public void setWorkAddress(String workAddress) {
        findElByName("workAddress").sendKeys(workAddress);
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка рабочего номера организации
     * @param phone - рабочий номера организации
     */
    @Step("Устанавливаем рабочий номер организации - {phone}")
    public void setWorkPhone(String phone) {
        findElByName("workPhone").sendKeys(phone);
    }

    /**
     * Установка слуайной почты
     */
    @Step("Устанавливаем случайную тестовую почту")
    public void setRandomEmail() {
        findElByName("clientEmail").sendKeys("testing" + new Random().nextInt(1000) + "@mail.ru");
    }

    /**
     * Установка заданной почты
     * @param email - почта
     */
    @Step("Устанавливаем почту - {email}")
    public void setEmail(String email) {
        findElByName("clientEmail").sendKeys(email);
    }

    /**
     * ! ТОЛЬКО ДЛЯ БИЗНЕСА
     * Установка телефона для связи
     * @param phone - телефон
     */
    @Step("Устанавливаем телефон для связи - {phone}")
    public void setClientPhone(String phone) {
        findElByName("clientPhone").sendKeys(phone);
    }

    /**
     * Согласие для пользовательского соглашение
     */
    @Step("Принимаем пользовательское соглашение")
    public void setAcceptTerms() {
        findElByXpath("//input[@id='acceptTerms']//../span[@class='check']").click();
    }

    /**
     * Согласие для условия обработки персональных данных
     */
    @Step("Принимаем условия обработки персональных данных")
    public void setTermsPersonData() {
        findElByXpath("//input[@id='termsPersonData']//../span[@class='check']").click();
    }

    /**
     * Отправка заявки на получение визы
     */
    @Step("Отправляем заявку на получение визы")
    public void sendVisa() {
        findElById("sendVisaForm").click();
    }
}
