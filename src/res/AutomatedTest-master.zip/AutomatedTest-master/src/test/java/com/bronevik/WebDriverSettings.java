package com.bronevik;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverSettings {

    protected WebDriver webDriver;
    protected WebDriverWait webDriverWait;

    @Rule
    public TestRule screenshotRule = new TestWatcher() {

        @Override
        protected void starting(Description description) {
            String browser = "";

            if (java.lang.System.getProperties().getProperty("webbrowser") != null)
                browser = java.lang.System.getProperties().getProperty("webbrowser");

            if (browser.toLowerCase().equals(""))
                webDriver = Browsers.chrome.getBrowser();

            else {
                for (Browsers browsers : Browsers.values()) {
                    if (browser.toLowerCase().equals(browsers.getBrowserName()))
                        webDriver = browsers.getBrowser();
                }
            }

            webDriverWait = new WebDriverWait(webDriver, 5);

            webDriver.manage().window().maximize();
        }

        @Override
        protected void finished(Description description) {
            webDriver.quit();
        }

        @Override
        protected void failed(Throwable e, Description description) {
            Utils.attachScreenshot(webDriver);
        }
    };
}
